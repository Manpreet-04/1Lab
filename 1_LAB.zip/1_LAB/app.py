from flask import Flask, render_template, request
import mysql.connector

app = Flask(__name__)

# Database connection settings
mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  database="userdb",
  port = 3306
)

@app.route('/')
def index():
    # Select all records from the database
    cursor = mydb.cursor()
    cursor.execute("SELECT * FROM users")
    result = cursor.fetchall()
    return render_template('index.html', rows=result)

@app.route('/add', methods=['POST'])
def add():
    # Get the data from the form
    word = request.form['word']
    rating = request.form['rating']
   
    
    # Insert the data into the database
    cursor = mydb.cursor()
    sql = "INSERT INTO users (word, rating) VALUES (%s, %s)"
    val = (word, rating)
    cursor.execute(sql, val)
    mydb.commit()

    return "Record added successfully!"

if __name__ == '__main__':
    app.run(debug=True)